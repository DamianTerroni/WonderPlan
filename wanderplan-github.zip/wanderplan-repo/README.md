# 🧭 Wanderplan

Prototipo de app para planificar viajes (proyecto APP Viaje). Un solo archivo estático (`index.html`) con:
mapa mundial interactivo offline, 115 destinos + creación de destinos propios, planificador con
cotización por temporada, generador de viaje aleatorio, itinerario día a día con horarios editables,
reservas con destino/fechas/viajeros precargados según estilo, documentos y embajadas según el país
de origen del usuario, y comunidad con opiniones.

> ⚠️ Prototipo: los datos viven en memoria (recargar la página resetea viajes guardados).

## Desplegar en Vercel (una vez subido a GitHub)

1. Entrá en [vercel.com/new](https://vercel.com/new) e **importá este repositorio**.
2. Framework Preset: **Other** · sin comando de build · Output: raíz.
3. **Deploy** → obtenés tu URL `https://<proyecto>.vercel.app`.

Desde entonces, **cada push a `main` se redespliega solo**.

## Cómo subir este repo a GitHub

**Opción sin terminal (más fácil):**
1. En github.com → **New repository** → nombre `wanderplan` → Create.
2. En la pantalla del repo nuevo, clic en **"uploading an existing file"**.
3. Arrastrá `index.html`, `vercel.json` y `README.md` → **Commit changes**.

**Opción con git:**
```bash
git remote add origin https://github.com/TU_USUARIO/wanderplan.git
git push -u origin main
```
(este repo ya viene con git inicializado y el primer commit hecho)
